import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ----------------------------
# 1. Load Dataset
# ----------------------------
df = pd.read_csv("diu.csv")

# ----------------------------
# 2. Basic Overview
# ----------------------------
print("\n--- Dataset Overview ---")
print("Total Students:", len(df))
print("Columns:", df.columns.tolist())
print("\nFirst 5 Records:")
print(df.head())

# ----------------------------
# 3. Data Cleaning
# ----------------------------
print("\n--- Missing Values ---")
print(df.isnull().sum())

print("\n--- Duplicate Records ---")
print(df.duplicated().sum())

# Drop duplicates if any
df.drop_duplicates(inplace=True)

# ----------------------------
# 4. Descriptive Statistics
# ----------------------------
print("\n--- Descriptive Statistics ---")
print(df.describe(include='all'))

# ----------------------------
# 5. Column Data Types
# ----------------------------
print("\n--- Data Types ---")
print(df.dtypes)

# ----------------------------
# 6. Age Analysis
# ----------------------------
plt.figure(figsize=(10, 4))
plt.hist(df['Age'], bins=10, color='skyblue', edgecolor='black')
plt.title('Age Distribution of Students')
plt.xlabel('Age')
plt.ylabel('Count')
plt.grid(True)
plt.show()

# ----------------------------
# 7. CGPA Analysis
# ----------------------------
plt.figure(figsize=(10, 4))
plt.hist(df['CGPA'], bins=10, color='orange', edgecolor='black')
plt.title('CGPA Distribution of Students')
plt.xlabel('CGPA')
plt.ylabel('Count')
plt.grid(True)
plt.show()

# Boxplot for CGPA
plt.figure(figsize=(6, 4))
plt.boxplot(df['CGPA'], vert=False)
plt.title('CGPA Boxplot')
plt.xlabel('CGPA')
plt.show()

# ----------------------------
# 8. Department Analysis
# ----------------------------
dep_counts = df['Department'].value_counts()
plt.figure(figsize=(8, 4))
dep_counts.plot(kind='bar', color='green')
plt.title('Number of Students per Department')
plt.xlabel('Department')
plt.ylabel('Count')
plt.grid(axis='y')
plt.show()

# ----------------------------
# 9. Average CGPA by Department
# ----------------------------
plt.figure(figsize=(8, 4))
avg_cgpa_dept = df.groupby('Department')['CGPA'].mean().sort_values()
avg_cgpa_dept.plot(kind='barh', color='coral')
plt.title('Average CGPA by Department')
plt.xlabel('Average CGPA')
plt.ylabel('Department')
plt.grid(axis='x')
plt.show()

# ----------------------------
# 10. Gender Analysis
# ----------------------------
plt.figure(figsize=(6, 4))
gender_counts = df['Gender'].value_counts()
plt.bar(gender_counts.index, gender_counts.values, color=['blue', 'pink'])
plt.title('Gender Distribution')
plt.xlabel('Gender')
plt.ylabel('Count')
plt.grid(True)
plt.show()

# Average CGPA by Gender
plt.figure(figsize=(6, 4))
avg_cgpa_gender = df.groupby('Gender')['CGPA'].mean()
plt.bar(avg_cgpa_gender.index, avg_cgpa_gender.values, color='purple')
plt.title('Average CGPA by Gender')
plt.ylabel('Average CGPA')
plt.show()

# ----------------------------
# 11. City-wise Analysis
# ----------------------------
plt.figure(figsize=(8, 8))
df['City'].value_counts().plot(kind='pie', autopct='%1.1f%%', startangle=140)
plt.title('Students by City')
plt.ylabel('')
plt.show()

# ----------------------------
# 12. Age vs CGPA Scatter Plot
# ----------------------------
plt.figure(figsize=(8, 4))
plt.scatter(df['Age'], df['CGPA'], c='teal', alpha=0.6)
plt.title('Age vs CGPA')
plt.xlabel('Age')
plt.ylabel('CGPA')
plt.grid(True)
plt.show()

# ----------------------------
# 13. Top Performers
# ----------------------------
thresh = np.percentile(df['CGPA'], 90)
top_10 = df[df['CGPA'] >= thresh]
print("\n--- Top 10% Students ---")
print(top_10[['Name', 'CGPA', 'Department']])
top_10.to_csv("top_10_percent.csv", index=False)

# ----------------------------
# 14. Correlation Matrix
# ----------------------------
plt.figure(figsize=(6, 4))
corr = df[['Age', 'CGPA']].corr()
plt.imshow(corr, cmap='coolwarm', interpolation='none')
plt.colorbar()
plt.xticks(range(len(corr)), corr.columns, rotation=45)
plt.yticks(range(len(corr)), corr.columns)
plt.title('Correlation Matrix')
for i in range(len(corr)):
    for j in range(len(corr)):
        plt.text(j, i, round(corr.iloc[i, j], 2), ha='center', va='center', color='black')
plt.tight_layout()
plt.show()

# ----------------------------
# 15. Departmental Gender Ratio
# ----------------------------
grouped = df.groupby(['Department', 'Gender']).size().unstack()
grouped.plot(kind='bar', stacked=True, figsize=(10, 6))
plt.title('Gender Distribution per Department')
plt.xlabel('Department')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.grid(True)
plt.tight_layout()
plt.show()

# ----------------------------
# 16. Export Cleaned Dataset
# ----------------------------
df.to_csv("cleaned_students_dataset.csv", index=False)
print("\nCleaned dataset saved as 'cleaned_students_dataset.csv'")

# ----------------------------
# 17. Advanced CGPA Stats
# ----------------------------
print("\nCGPA Standard Deviation:", np.std(df['CGPA']))
print("CGPA Variance:", np.var(df['CGPA']))
print("Highest CGPA:", df['CGPA'].max())
print("Lowest CGPA:", df['CGPA'].min())

# ----------------------------
# 18. Filter by User Input (Department)
# ----------------------------
dep_input = input("Enter a department name to filter students: ").strip().upper()
if dep_input in df['Department'].str.upper().unique():
    filtered = df[df['Department'].str.upper() == dep_input]
    print(filtered)
    filtered.to_csv(f"students_{dep_input}.csv", index=False)
    print(f"Filtered students saved to students_{dep_input}.csv")
else:
    print("Department not found.")

# ----------------------------
# 19. Plot CGPA Ranges
# ----------------------------
def cgpa_range(cgpa):
    if cgpa >= 3.5:
        return 'Excellent'
    elif cgpa >= 3.0:
        return 'Good'
    elif cgpa >= 2.5:
        return 'Average'
    else:
        return 'Poor'

df['Performance'] = df['CGPA'].apply(cgpa_range)

plt.figure(figsize=(8, 4))
performance_counts = df['Performance'].value_counts().reindex(['Poor', 'Average', 'Good', 'Excellent'])
plt.bar(performance_counts.index, performance_counts.values, color='slateblue')
plt.title('Student Performance Levels')
plt.xlabel('Performance')
plt.ylabel('Number of Students')
plt.grid(True)
plt.show()

# ----------------------------
# 20. Save Final Report
# ----------------------------
final_stats = df.groupby('Performance').size().reset_index(name='Count')
final_stats.to_csv("performance_summary.csv", index=False)
print("\nPerformance summary saved as 'performance_summary.csv'")

# ----------------------------
# 21. Enrollment Year Trend (if available)
# ----------------------------
if 'AdmissionYear' in df.columns:
    plt.figure(figsize=(8, 4))
    df['AdmissionYear'].value_counts().sort_index().plot(kind='line', marker='o', color='darkgreen')
    plt.title('Year-wise Student Enrollment')
    plt.xlabel('Year')
    plt.ylabel('Number of Students')
    plt.grid(True)
    plt.show()

# ----------------------------
# 22. Pie Chart of Performance
# ----------------------------
plt.figure(figsize=(6, 6))
df['Performance'].value_counts().plot(kind='pie', autopct='%1.1f%%', startangle=90)
plt.title('Performance Distribution')
plt.ylabel('')
plt.tight_layout()
plt.show()

# ----------------------------
# 23. Histogram of CGPA by Gender
# ----------------------------
plt.figure(figsize=(10, 4))
for gender in df['Gender'].unique():
    plt.hist(df[df['Gender'] == gender]['CGPA'], bins=10, alpha=0.5, label=gender)
plt.title('CGPA Distribution by Gender')
plt.xlabel('CGPA')
plt.ylabel('Count')
plt.legend()
plt.grid(True)
plt.show()

# ----------------------------
# 24. Average Age by Department
# ----------------------------
plt.figure(figsize=(8, 4))
df.groupby('Department')['Age'].mean().sort_values().plot(kind='bar', color='tomato')
plt.title('Average Age by Department')
plt.xlabel('Department')
plt.ylabel('Average Age')
plt.grid(True)
plt.tight_layout()
plt.show()

# ----------------------------
# 25. Age Group Distribution
# ----------------------------
df['AgeGroup'] = pd.cut(df['Age'], bins=[17, 20, 23, 26, 30], labels=['18-20', '21-23', '24-26', '27-30'])
plt.figure(figsize=(6, 4))
df['AgeGroup'].value_counts().sort_index().plot(kind='bar', color='mediumslateblue')
plt.title('Age Group Distribution')
plt.xlabel('Age Group')
plt.ylabel('Number of Students')
plt.grid(True)
plt.tight_layout()
plt.show()

# ----------------------------
# 26. Age & CGPA Subplots
# ----------------------------
fig, axs = plt.subplots(1, 2, figsize=(12, 5))
axs[0].hist(df['Age'], color='lightblue', edgecolor='black')
axs[0].set_title('Age Distribution')
axs[0].set_xlabel('Age')
axs[0].set_ylabel('Count')
axs[0].grid(True)

axs[1].hist(df['CGPA'], color='salmon', edgecolor='black')
axs[1].set_title('CGPA Distribution')
axs[1].set_xlabel('CGPA')
axs[1].set_ylabel('Count')
axs[1].grid(True)

plt.tight_layout()
plt.show()

# ----------------------------
# 27. Students with Low CGPA
# ----------------------------
low_cgpa_df = df[df['CGPA'] < 2.5]
low_cgpa_df.to_csv("low_cgpa_students.csv", index=False)
print("\nStudents with CGPA below 2.5 saved in 'low_cgpa_students.csv'")
