# streamlit_app.py

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

st.set_page_config(page_title="DIU Student Analysis", layout="wide")

# ----------------------------
# Branding & Header
# ----------------------------

st.title("🎓 DIU Student Data Analysis Dashboard")
st.markdown("##### Explore insights from university student records")
st.markdown("<center><h5 style='color:gray;'>Made with ❤️ by <b>Tamim Mahmud</b></h5></center>", unsafe_allow_html=True)
st.markdown("---")

# ----------------------------
# Sidebar Navigation
# ----------------------------
with st.sidebar:
    st.header("🔍 Navigation")
    view = st.radio("Go to section", [
        "Overview", 
        "Age & CGPA Distribution", 
        "Department Analysis", 
        "Gender Insights", 
        "Top Performers", 
        "Performance Levels", 
        "Custom Filter"
    ])
    st.markdown("---")
    st.markdown("Made with ❤️ by **Tamim Mahmud**")

# ----------------------------
# Load and Prepare Data
# ----------------------------
df = pd.read_csv("diu.csv")
df.drop_duplicates(inplace=True)

def cgpa_range(cgpa):
    if cgpa >= 3.5:
        return 'Excellent'
    elif cgpa >= 3.0:
        return 'Good'
    elif cgpa >= 2.5:
        return 'Average'
    else:
        return 'Poor'

# ----------------------------
# Views
# ----------------------------

if view == "Overview":
    st.subheader("📁 Dataset Overview")
    st.write(f"**Total Students:** {len(df)}")
    st.dataframe(df.head())

    st.subheader("📊 Descriptive Statistics")
    st.write(df.describe())

    st.subheader("🧹 Data Quality")
    col1, col2 = st.columns(2)
    with col1:
        st.write("Missing Values:")
        st.write(df.isnull().sum())
    with col2:
        st.write("Duplicate Rows:", df.duplicated().sum())

elif view == "Age & CGPA Distribution":
    st.subheader("🎂 Age Distribution")
    fig, ax = plt.subplots()
    ax.hist(df['Age'], bins=10, color='skyblue', edgecolor='black')
    st.pyplot(fig)

    st.subheader("📘 CGPA Distribution")
    col1, col2 = st.columns(2)
    with col1:
        fig1, ax1 = plt.subplots()
        ax1.hist(df['CGPA'], bins=10, color='orange', edgecolor='black')
        st.pyplot(fig1)

    with col2:
        fig2, ax2 = plt.subplots()
        ax2.boxplot(df['CGPA'], vert=False)
        st.pyplot(fig2)

    st.subheader("🧪 Age vs CGPA")
    fig3, ax3 = plt.subplots()
    ax3.scatter(df['Age'], df['CGPA'], c='teal', alpha=0.6)
    ax3.set_xlabel("Age")
    ax3.set_ylabel("CGPA")
    st.pyplot(fig3)

elif view == "Department Analysis":
    st.subheader("🏫 Department Distribution")
    st.bar_chart(df['Department'].value_counts())

    st.subheader("📈 Average CGPA by Department")
    avg_cgpa = df.groupby('Department')['CGPA'].mean().sort_values()
    st.bar_chart(avg_cgpa)

    st.subheader("👩‍🎓 Gender Distribution by Department")
    gender_dept = df.groupby(['Department', 'Gender']).size().unstack().fillna(0)
    st.bar_chart(gender_dept)

elif view == "Gender Insights":
    st.subheader("👥 Gender Distribution")
    st.bar_chart(df['Gender'].value_counts())

    st.subheader("🎯 Average CGPA by Gender")
    avg_cgpa_gender = df.groupby('Gender')['CGPA'].mean()
    st.bar_chart(avg_cgpa_gender)

    st.subheader("📊 CGPA Distribution by Gender")

    genders = df['Gender'].unique()
    fig, ax = plt.subplots(figsize=(10, 4))

    for gender in genders:
        cgpas = df[df['Gender'] == gender]['CGPA']
        ax.hist(cgpas, bins=10, alpha=0.5, label=gender, edgecolor='black')

    ax.set_title("CGPA Distribution by Gender")
    ax.set_xlabel("CGPA")
    ax.set_ylabel("Number of Students")
    ax.legend()
    ax.grid(True)

    st.pyplot(fig)

elif view == "Top Performers":
    st.subheader("🏆 Top 10% Students")
    thresh = np.percentile(df['CGPA'], 90)
    top_10 = df[df['CGPA'] >= thresh]
    st.write(top_10[['Name', 'CGPA', 'Department']])
    
    if st.button("💾 Export Top 10%"):
        top_10.to_csv("top_10_percent.csv", index=False)
        st.success("Saved as top_10_percent.csv")

elif view == "Performance Levels":
    st.subheader("🎯 Performance Classification")
    df['Performance'] = df['CGPA'].apply(cgpa_range)
    
    perf_counts = df['Performance'].value_counts().reindex(['Poor', 'Average', 'Good', 'Excellent']).fillna(0)
    st.bar_chart(perf_counts)

    st.subheader("📊 Performance Distribution (Pie)")
    fig, ax = plt.subplots()
    ax.pie(perf_counts, labels=perf_counts.index, autopct='%1.1f%%', startangle=90)
    ax.axis("equal")
    st.pyplot(fig)

elif view == "Custom Filter":
    st.subheader("🛠️ Filter by Department")
    dep = st.selectbox("Choose a department", df['Department'].unique())
    result = df[df['Department'] == dep]
    st.write(result)

    if st.button("💾 Save Filtered Results"):
        result.to_csv(f"students_{dep}.csv", index=False)
        st.success(f"Saved as students_{dep}.csv")

# ----------------------------
# Footer
# ----------------------------
st.markdown("""---""")
#st.markdown("<center><small>Made with ❤️ by <b>Tamim Mahmud</b></small></center>", unsafe_allow_html=True)
